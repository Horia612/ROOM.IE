const express = require('express');
const session = require('express-session');
const path = require("path");
const preference = require("./routes/preferences")
const addUser = require("./db/dbQueries")

const app = express();
const PORT = process.env.PORT || "3000";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");


app.use(session({
    secret: 'my-secret',
    resave: false,
    saveUninitialized: true
}));

app.get('/users/', (req, res) => {
    const id = req.query.id;

    if (!id) {
        res.status(400)
        res.send("No id introduced")
    } else {
        preference.getPreferences(id, res)
    }
});

app.get("/signup", (req, res) => {
    if (!req.query.username || !req.query.password) {
        res.render("signup", {
            title: "ROOM.IE | Login",
            text: "Fill all the fields",
            login: "Login",
            post: ""
        });
    } else {
        let user = {
            name: req.query.username,
            password: req.query.password,
            preference: req.query.preferences.split(' ').join(',')
        }
        console.log(user);
        // add user to db
        addUser.addUserQuery(user, res)
        res.redirect("/login")
    }
})

app.get("/post", (req, res) => {
    if(req.session.user) {

        // add to db the post
        if(req.query.location && req.query.description) {
        let post = {
            id: req.session.user.id,
            location: req.query.location,
            description: req.query.description
        }

        addUser.addPostToDB(post)
        res.redirect("/");
    } else {
        res.render("post", {
            title: "ROOM.IE | Login",
            text: "Please fill out the form",
            post: "Post",
            login: ""
        });
    }
    } else {
        res.redirect("/");
    }
})

app.post("/signup/", (req, res) => {

    // check if all field s are filled

    if (!req.body.name || !req.body.password) {
        res.status(400);
        res.send("Please fill all fields");
        return;
    }

    // create user object
    let user = {
        name: req.body.name,
        password: req.body.password,
        preference: req.body.preference
    }

    // add user to db
    addUser.addUserQuery(user, res)
})



app.get('/', require('./routes/index'));

app.get('/login', require('./routes/login'));
app.get('/search', require('./routes/search'));

app.listen(PORT, console.log('Server is running on port ' + PORT));