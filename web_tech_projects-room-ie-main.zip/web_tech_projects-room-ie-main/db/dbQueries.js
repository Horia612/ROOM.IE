function addUserToDB(user) {
    // add user to db
    const client = require('../db/database.js');
    const values = [user.name, user.password];
    const prefValue = [user.preference]
    const queryText = `
        INSERT INTO users (name, password)
        VALUES (?, ?)
      `;
      const queryTextPreferences =`
      INSERT INTO UserPreferences (CommuneThings)
      VALUES(?)`
    client.run(queryText, values, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log('User added to db');
        }
    });

    client.run(queryTextPreferences, prefValue, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log('Users preferences added to db');
        }
    })
}

function addUserQuery(user, res) {
    const client = require('../db/database.js');
    // check if user already exists query
    const checkUserQuery = `SELECT * FROM users WHERE name = ?`;
    
    client.get(checkUserQuery, [user.name], (err, row) => {
        // if call to db fails
        if (err) {
            console.log(err);
        } else if (row) {
            // if user already exists
            console.log('User already exists');
        } else {
            // if user does not exist
            addUserToDB(user);
            console.log('User added to db' + user.name);
        }
    });
}

async function getPosts() {
    try{
        return await new Promise((resolve, reject) => {
            const client = require('../db/database.js');
            const queryText = `
            SELECT * 
            FROM Posts 
            FULL JOIN UserPreferences 
            ON Posts.IdUserSesion = UserPreferences.IdUser
            FULL JOIN users
            ON users.id = UserPreferences.IdUser
            WHERE Posts.Description IS NOT NULL
            LIMIT 10
            `;
            client.all(queryText, (err, result) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(result);
                }
            });
        });
    } catch(err) {
        console.log("Error: ", err);
    }
}

function addPostToDB(post) {
    // add user to db
    const client = require('../db/database.js');
    const values = [post.location, post.description, post.id];

    const queryText = `
        INSERT INTO Posts (Location, Description, IdUserSesion)
        VALUES (?, ?, ?)
      `;

    client.run(queryText, values, (err) => {
        if (err) {
            console.log(err);
        } else {
            console.log('Post added to db');
        }
    });
}

module.exports = {
    addUserQuery,
    addPostToDB,
    getPosts
}