const searchView = async (req, res) => {
    if (req.session.user === undefined)
        res.redirect("/login")
    else
        if (!req.query.city) {
            res.redirect("/")
        } else {
            console.log(req.session.user)
            let prefs = await preference.getPreferences(req.session.user.id);

            const list = Object.entries(prefs.userCompatabilityWithOtherUsers)
                .filter(([, value]) => value !== '0%')
                .sort((a, b) => b[1] - a[1])
                .map(([key]) => key);

            posts = await retrievePosts(req.query.city, list)
            console.log(posts);
            res.render("search", {
                title: "ROOM.IE | Login",
                text: "Please fill out the form",
                post: "Post",
                posts: posts,
                login: ""
            });
        }
}
const preference = require("../routes/preferences")

async function retrievePosts(city, ids) {
    try {
        return await new Promise((resolve, reject) => {
            const client = require('../db/database.js');
            // let results = []
            // for (id in ids) {
            ids = ids.join(', ')
            const queryText = `
                    SELECT * 
                    FROM Posts 
                    FULL JOIN UserPreferences 
                    ON Posts.IdUserSesion = UserPreferences.IdUser
                    FULL JOIN users
                    ON users.id = UserPreferences.IdUser
                    WHERE Posts.Description IS NOT NULL 
                        and Posts.Location ='` + city + `'
                        and Posts.IdUserSesion IN (`+ ids + `);
                    LIMIT 10
                    `;

            client.all(queryText, (err, result) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(result);
                }
            });
            // }
            // console.log(results);
        });
    } catch (err) {
        console.log("Error: ", err);
    }
}
module.exports = {
    searchView
};