const db = require("../db/dbQueries")
const indexView = async (req, res) => {
    let posts = await db.getPosts()
    if(req.session.user) {
        res.render("index", {
            title: "ROOM.IE | " + req.session.user.username,
            login: "",
            post: "Post",
            posts: posts
        } );
    }
    res.render("index", {
        title: "ROOM.IE | Home",
        login: "Login",
        post: "",
        posts: posts
    } );
}

module.exports =  {
    indexView
};